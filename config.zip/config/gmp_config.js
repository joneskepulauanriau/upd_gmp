'use strict';

const path = require('path');

function envBoolean(name, defaultValue = false) {
  const value = process.env[name];
  if (value == null || value === '') return defaultValue;
  return ['1', 'true', 'yes', 'y', 'on'].includes(String(value).toLowerCase());
}

function envInteger(name, defaultValue) {
  const value = Number.parseInt(process.env[name], 10);
  return Number.isFinite(value) ? value : defaultValue;
}

function envList(name, defaultValue = []) {
  const value = process.env[name];
  if (!value) return [...defaultValue];
  return value.split(',').map((item) => item.trim()).filter(Boolean);
}

const ROOT_DIR = path.resolve(__dirname, '..', '..');

const COMMANDS = Object.freeze({
  RANKING: 'buat ranking pemain',
  RANKING_INFOGRAPHIC: 'buat infografis ranking pemain',
  HEAD_TO_HEAD: 'buat head to head pemain',
  HEAD_TO_HEAD_SHORT: 'buat head to head',
  LIST_TOURNAMENTS: 'buat data turnamen',
  TOURNAMENT_PLAN: 'buat rencana turnamen',
  LIST_PLAYERS: 'buat data pemain',
  BEST_POSITION: 'buat posisi terbaik',
  REGISTER_ME: 'daftarkan saya',
  REGISTER_PLAYER: 'daftarkan',
  PLAYER_PROFILE: 'buat profil pemain',
  BUILD_POOL: 'buat pool',
  ATTENDANCE_RECAP: 'buat rekap presensi',
  RE_REGISTER: 'registrasi ulang',
  DUO_TEAM: 'bereguduo',
  DOUBLES: 'ganda',
  REWARD: 'reward',
  REWARD_LIST: 'listreward',
  START_IMPORT: 'mulai import data',
  RESET_MATCHES: 'reset pertandingan',
  ADMIN_DATA_ON: 'mode sql on',
  ADMIN_DATA_OFF: 'mode sql off',
  CHECK_SALDO: 'cek saldo gmp',
  SALDO_DETAIL: 'cek saldo detil',
});

const ADMIN_COMMANDS = Object.freeze({
  APP_ON: 'set appgmp on',
  APP_OFF: 'set appgmp off',
  APP_STATUS: 'status appgmp',
});

const APP_STATUS = Object.freeze({ ON: 'ON', OFF: 'OFF' });

const config = Object.freeze({
  rootDir: ROOT_DIR,
  paths: Object.freeze({
    auth: path.join(ROOT_DIR, 'auth_multi_device'),
    parameters: path.join(ROOT_DIR, 'parameters.json'),
    locations: path.join(ROOT_DIR, 'locations.json'),
    debugOcr: path.join(ROOT_DIR, 'debug_ocr'),
    images: path.join(ROOT_DIR, 'src', 'images'),
    groups: path.join(ROOT_DIR, 'src', 'grup'),
  }),
  whatsapp: Object.freeze({
    browser: ['GMP Bot', 'Chrome', '2.0.0'],
    syncFullHistory: false,
    markOnlineOnConnect: true,
    reconnectDelayMs: envInteger('RECONNECT_DELAY_MS', 5000),
    loggerLevel: process.env.BAILEYS_LOG_LEVEL || 'silent',
  }),
  access: Object.freeze({
    authorizingUser: String(process.env.AUTHORIZING_USER || '').replace(/\D/g, ''),
    allowedGroupJids: envList('ALLOWED_GROUP_JIDS', [
      '120363401358668785@g.us',
      '120363177930974800@g.us',
    ]),
  }),
  app: Object.freeze({
    parametersRecordId: String(process.env.PARAMETERS_RECORD_ID || '1'),
    defaultStatus: APP_STATUS.ON,
  }),
  qris: Object.freeze({
    validTerminalId: String(process.env.VALID_TERMINAL_ID || '024303044'),
    saveDebugOcr: envBoolean('SAVE_DEBUG_OCR', true),
    pointsUnitAmount: envInteger('REWARD_POINT_UNIT_AMOUNT', 10000),
  }),
  attendance: Object.freeze({
    minimumAttendance: envInteger('MINIMUM_ATTENDANCE', 3),
  }),
  tournament: Object.freeze({
    duoAlias: String(process.env.DUO_TOURNAMENT_ALIAS || 'kedelapan').toLowerCase(),
    duoTournamentId: envInteger('DUO_TOURNAMENT_ID', 202513),
    doublesAlias: String(process.env.DOUBLES_TOURNAMENT_ALIAS || 'keduabelas').toLowerCase(),
    doublesTournamentId: envInteger('DOUBLES_TOURNAMENT_ID', 202515),
  }),
  sessions: Object.freeze({
    ttlMs: envInteger('SESSION_TTL_MS', 30 * 60 * 1000),
  }),
});

const PUBLIC_COMMANDS = new Set([
  COMMANDS.REWARD_LIST,
  COMMANDS.ATTENDANCE_RECAP,
  COMMANDS.RANKING_INFOGRAPHIC,
  COMMANDS.RANKING,
  COMMANDS.HEAD_TO_HEAD,
  COMMANDS.HEAD_TO_HEAD_SHORT,
  COMMANDS.LIST_TOURNAMENTS,
  COMMANDS.LIST_PLAYERS,
  COMMANDS.BEST_POSITION,
  COMMANDS.REGISTER_PLAYER,
  COMMANDS.REGISTER_ME,
  COMMANDS.PLAYER_PROFILE,
  COMMANDS.TOURNAMENT_PLAN,
  COMMANDS.BUILD_POOL,
  COMMANDS.RE_REGISTER,
  COMMANDS.CHECK_SALDO,
  COMMANDS.SALDO_DETAIL,
  'tambah',
  'hapus',
  'perbaiki',
  'perbaiki status',
  'perbaiki realisasi',
]);

module.exports = {
  config,
  COMMANDS,
  ADMIN_COMMANDS,
  APP_STATUS,
  PUBLIC_COMMANDS,
};
