'use strict';

const assert = require('assert');
const { parseCommand } = require('../src/core/command_parser');
const { getPool, pairDuo } = require('../src/core/pool');
const { getNominal, getRefId, validateQrisText } = require('../src/core/qris_parser');
const { isTimeWithinRange } = require('../src/core/time_utils');
const { getTransactionDate } = require('../src/core/transaction_date');

assert.deepStrictEqual(parseCommand('registrasi ulang 2026001'), {
  perintah: 'registrasi ulang',
  parameter: ['2026001'],
});
assert.deepStrictEqual(parseCommand('Daftarkan Muhammad Yunus pada turnamen Kedua'), {
  perintah: 'daftarkan',
  parameter: ['Muhammad Yunus', 'kedua'],
});
assert.strictEqual(getPool(2, 3), 'A');
assert.strictEqual(pairDuo([
  { nama_pemain: 'A', ranking_sebelum: 1 },
  { nama_pemain: 'B', ranking_sebelum: 2 },
]).length, 1);
assert.strictEqual(getNominal('Pembayaran berhasil\nRp100.000,00'), 100000);
assert.strictEqual(getRefId('Ref 19313990018'), '19313990018');
assert.strictEqual(validateQrisText('Pembayaran QRIS Berhasil Terminal ID 024303044', '024303044'), true);
assert.strictEqual(isTimeWithinRange('19:00:00', '18:00:00', '20:00:00'), true);
assert.strictEqual(getTransactionDate('10/07/2026 - 19:31:41 WIB'), '2026-07-10T12:31:41.000Z');
assert.strictEqual(getTransactionDate('07 Jul 2026 16:53:57 WIB'), '2026-07-07T09:53:57.000Z');

console.log('Semua pemeriksaan dasar berhasil.');
