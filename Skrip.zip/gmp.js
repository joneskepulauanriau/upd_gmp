'use strict';

require('dotenv').config();

const pino = require('pino');
const qrcode = require('qrcode-terminal');
const makeWASocket = require('@whiskeysockets/baileys').default;
const {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');

const {
  config,
  COMMANDS,
  PUBLIC_COMMANDS,
  APP_STATUS,
} = require('./src/config/gmp_config');
const { SessionStore } = require('./src/core/session_store');
const { ParameterStore } = require('./src/core/parameter_store');
const { createMessageContext } = require('./src/core/message_context');
const { parseCommand } = require('./src/core/command_parser');
const { QrisService } = require('./src/services/qris_service');
const { getUserByContext } = require('./src/services/domain_service');
const {
  isAdmin,
  getAppStatus,
  handleAdminControl,
  handleActiveSession,
} = require('./src/handlers/admin_handler');
const { handleQrisImage } = require('./src/handlers/qris_handler');
const { handleAttendanceLocation } = require('./src/handlers/attendance_handler');
const { createCommandRouter } = require('./src/handlers/command_router');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });
const baileysLogger = pino({ level: config.whatsapp.loggerLevel });
const sessions = new SessionStore(config.sessions);
const parameterStore = new ParameterStore(config.paths.parameters);
const qrisService = new QrisService({
  logger,
  validTerminalId: config.qris.validTerminalId,
  saveDebugOcr: config.qris.saveDebugOcr,
  debugDirectory: config.paths.debugOcr,
});

const dependencies = {
  config,
  logger,
  sessions,
  parameterStore,
  qrisService,
  getUserByContext,
};
const routeCommand = createCommandRouter(dependencies);

let activeSocket = null;
let reconnectTimer = null;
let shuttingDown = false;
let starting = false;

function isAllowedGroup(context) {
  return context.isGroup && config.access.allowedGroupJids.includes(context.remoteJid);
}

async function isAuthorizedContext(context) {
  if (isAdmin(context, config)) return true;
  const user = await getUserByContext(context);
  if (!user.success) return false;
  if (context.isGroup) return isAllowedGroup(context);
  return config.access.allowRegisteredPrivateUsers;
}

function isPublicCommand(command) {
  const menu = String(command.perintah || '').toLowerCase();
  return PUBLIC_COMMANDS.has(menu) || menu === 'buat profil' || menu === COMMANDS.REWARD;
}

async function processMessage(sock, rawMessage) {
  const context = createMessageContext(rawMessage);
  if (!context.content || context.isFromMe) return;

  const textLower = context.text.toLowerCase();
  logger.info(
    {
      remoteJid: context.remoteJid,
      senderNumber: context.senderNumber,
      senderName: context.senderName,
      isGroup: context.isGroup,
      messageType: context.messageType,
      text: context.text,
    },
    'Pesan diterima',
  );

  if (
    await handleAdminControl({
      sock,
      context,
      textLower,
      dependencies,
    })
  ) {
    return;
  }

  const appStatus = await getAppStatus(parameterStore, config);
  if (appStatus === APP_STATUS.OFF) return;

  const command = parseCommand(context.text);

  // Registrasi ulang harus dapat dilakukan sebelum pengguna dikenali.
  if (
    command.perintah === COMMANDS.RE_REGISTER &&
    context.isGroup &&
    isAllowedGroup(context)
  ) {
    await routeCommand({ sock, context, command });
    return;
  }

  const authorized = await isAuthorizedContext(context);
  if (!authorized) return;

  if (
    await handleActiveSession({
      sock,
      context,
      command,
      dependencies,
    })
  ) {
    return;
  }

  if (await handleQrisImage({ sock, context, dependencies })) return;
  if (await handleAttendanceLocation({ sock, context, dependencies })) return;

  if (!context.text) return;
  if (!isAdmin(context, config) && !isPublicCommand(command)) return;

  const handled = await routeCommand({ sock, context, command });
  if (!handled && isAdmin(context, config)) {
    logger.debug({ command }, 'Perintah tidak memiliki handler');
  }
}

function scheduleReconnect() {
  if (shuttingDown || reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    startBot().catch((error) => {
      logger.error({ error }, 'Gagal memulai ulang bot');
      scheduleReconnect();
    });
  }, config.whatsapp.reconnectDelayMs);
}

async function startBot() {
  if (starting || shuttingDown) return activeSocket;
  starting = true;

  try {
    const { state, saveCreds } = await useMultiFileAuthState(config.paths.auth);
    const { version, isLatest } = await fetchLatestBaileysVersion();
    logger.info({ version: version.join('.'), isLatest }, 'Versi WhatsApp Web');

    const sock = makeWASocket({
      version,
      logger: baileysLogger,
      printQRInTerminal: false,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, baileysLogger),
      },
      syncFullHistory: config.whatsapp.syncFullHistory,
      markOnlineOnConnect: config.whatsapp.markOnlineOnConnect,
      browser: config.whatsapp.browser,
    });
    activeSocket = sock;

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
      if (qr) {
        logger.info('Pindai QR melalui WhatsApp > Perangkat tertaut');
        qrcode.generate(qr, { small: true });
      }

      if (connection === 'open') {
        logger.info('WhatsApp terhubung');
        return;
      }

      if (connection !== 'close') return;
      const statusCode =
        lastDisconnect?.error?.output?.statusCode ||
        lastDisconnect?.error?.data?.statusCode;
      const loggedOut = statusCode === DisconnectReason.loggedOut;

      logger.warn(
        { statusCode, error: lastDisconnect?.error?.message },
        'Koneksi WhatsApp terputus',
      );
      activeSocket = null;

      if (loggedOut) {
        logger.error('Sesi logout. Hapus folder auth_multi_device untuk login ulang.');
      } else {
        scheduleReconnect();
      }
    });

    sock.ev.on('messages.upsert', async ({ messages = [], type }) => {
      if (type && type !== 'notify') return;
      for (const message of messages) {
        try {
          await processMessage(sock, message);
        } catch (error) {
          logger.error({ error }, 'Gagal memproses pesan');
        }
      }
    });

    return sock;
  } finally {
    starting = false;
  }
}

async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, 'Mematikan bot');

  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  sessions.clear();
  await qrisService.close();

  try {
    activeSocket?.end?.(new Error(`Shutdown: ${signal}`));
  } catch (error) {
    logger.warn({ error }, 'Socket tidak dapat ditutup dengan normal');
  }

  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (error) => {
  logger.error({ error }, 'Unhandled promise rejection');
});
process.on('uncaughtException', (error) => {
  logger.fatal({ error }, 'Uncaught exception');
  shutdown('uncaughtException');
});

startBot().catch((error) => {
  logger.fatal({ error }, 'Bot gagal dijalankan');
  scheduleReconnect();
});
