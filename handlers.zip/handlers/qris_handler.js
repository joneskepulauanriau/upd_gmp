'use strict';

const { insertData, getDataRow, getDataRowQuery } = require('../model/gmp_service');
const { getTransactionDate } = require('../core/transaction_date');
const { sendText, setTyping } = require('../core/bot_io');
const { getUserByContext } = require('../services/domain_service');

async function handleQrisImage({ sock, context, dependencies }) {
  const { qrisService, config, logger } = dependencies;
  if (!context.isImage) return false;

  try {
    const ocrText = await qrisService.readMessageImage(sock, context.raw, context.content);
    if (!qrisService.validate(ocrText)) return false;

    await setTyping(sock, context.remoteJid);
    const parsed = qrisService.parse(ocrText, getTransactionDate);
    const { refId, transactionDate, amount } = parsed;

    if (!refId || refId === '-' || !amount || amount <= 0 || !transactionDate || transactionDate === '-') {
      await sendText(
        sock,
        context.remoteJid,
        'Bukti transfer dikenali, tetapi Ref ID, tanggal, atau nominal belum terbaca dengan lengkap.',
      );
      return true;
    }

    const userResult = await getUserByContext(context);
    if (!userResult.success) {
      await sendText(sock, context.remoteJid, 'Pengguna belum terdaftar. Lakukan registrasi terlebih dahulu.');
      return true;
    }
    const playerId = userResult.data[0].id_pemain;
    const nama_pemain = userResult.data[0].nama_pemain;

    const existing = await getDataRow('*', 'reward', { ref_id: refId });
    if (existing.success) {
      await sendText(sock, context.remoteJid, 'Transaksi sudah pernah dicatat sebelumnya.');
      return true;
    }

    const insertResult = await insertData('reward', {
      id_pemain: playerId,
      ref_id: refId,
      tgl_transaksi: transactionDate,
      nominal: amount,
      kode_transaksi: 1,
      tgl_input: new Date(),
    });

    const insertSaldoResult = await insertData('saldo', {
      tgl_transaksi: new Date(),
      uraian: `Donasi an. ${nama_pemain}`,
      jumlah: amount,
      kode_transaksi: `D`,
    });

    if (!insertResult.success) {
      await sendText(sock, context.remoteJid, insertResult.message);
      return true;
    }

    const totals = await getDataRowQuery({
      columns: ['id_pemain', 'SUM(nominal) AS total_reward'],
      from: 'reward',
      filters: { 'id_pemain =': playerId },
      groupBy: 'id_pemain',
    });
    const totalAmount = totals.success ? Number(totals.data[0].total_reward || 0) : amount;
    const unit = config.qris.pointsUnitAmount;

    await sendText(
      sock,
      context.remoteJid,
      `Anda telah berdonasi sebesar *${amount.toLocaleString('id-ID')}* dan memperoleh *${amount / unit}* poin. Total reward Anda: *${totalAmount / unit}* poin.`,
    );

    logger.info(
      { remoteJid: context.remoteJid, playerId, refId, transactionDate, amount },
      'Transaksi QRIS tersimpan',
    );
    return true;
  } catch (error) {
    logger.error({ error }, 'Gagal membaca bukti transfer');
    await sendText(
      sock,
      context.remoteJid,
      'Transaksi gagal diproses. Kirim ulang bukti transfer dengan gambar yang lebih jelas.',
    );
    return true;
  }
}

module.exports = { handleQrisImage };
