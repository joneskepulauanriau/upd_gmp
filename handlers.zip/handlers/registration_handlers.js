'use strict';

const {
  getDataRow,
  insertData,
  updateData,
} = require('../model/gmp_service');
const { sendText, sendImage, setTyping } = require('../core/bot_io');
const { getPool, pairDuo } = require('../core/pool');
const {
  getUserByContext,
  resolvePlayer,
  resolveTournament,
  getPreviousRanking,
  getAttendanceCount,
  getRewardPoints,
  getTournamentRegistrations,
} = require('../services/domain_service');
const { buildParticipantList, formatDate, formatDateShort } = require('./query_handlers');
const { COMMANDS } = require('../config/gmp_config');

function tournamentStatusMessage(tournament) {
  const status = String(tournament.status || '').toLowerCase();
  if (status === 'tutup') {
    return `Status turnamen *TUTUP* dan akan dibuka tanggal *${formatDate(tournament.tgl_turnamen)}*.`;
  }
  if (status === 'selesai') {
    return `Status turnamen *SELESAI* pada tanggal *${formatDate(tournament.tgl_realisasi)}*.`;
  }
  return '';
}

function determineInitialPool(ranking) {
  if (Number(ranking) === 99) return 'X';
  const groupCount = Math.ceil(Number(ranking) / 3);
  return getPool(groupCount, Number(ranking)) || 'X';
}

async function sendTournamentRegistrationList({
  sock,
  context,
  tournamentId,
  mode,
  dependencies,
}) {
  const result = await getTournamentRegistrations(tournamentId);
  if (!result.success || !Array.isArray(result.data) || !result.data.length) return;

  if (mode === COMMANDS.DUO_TEAM || mode === COMMANDS.DOUBLES) {
    const players = result.data.map((item, index) => ({
      sequence: index + 1,
      id_pemain: item.id_pemain,
      nama_pemain: item.nama_pemain,
      ranking_sebelum: Number(item.ranking_sebelum),
    }));
    const pairs = pairDuo(players);
    const groupCount = Math.ceil(pairs.length / 3);
    const list = pairs
      .map((item, index) => ({
        ...item,
        pool: getPool(groupCount, index + 1) || 'X',
      }))
      .sort((a, b) => a.pool.localeCompare(b.pool));

    let text = `DAFTAR PESERTA TURNAMEN\n${result.data[0].nama_turnamen}\nTanggal : ${formatDateShort(result.data[0].tgl_realisasi)}\n\n*No. Nama Pasangan        Pool*\n`;
    list.forEach((item, index) => {
      text += `${String(index + 1).padStart(3, ' ')}. ${item.nama_pasangan} *${item.pool}*\n`;
    });
    await sendText(sock, context.remoteJid, text);
    if (groupCount >= 2) {
      await sendImage(sock, context.remoteJid, `./src/grup/${groupCount}.jpg`, 'Babak Lanjutan');
    }
    return;
  }

  const list = buildParticipantList(result.data);
  await sendText(sock, context.remoteJid, list.text);
  if (list.groupCount !== 2) {
    await sendImage(sock, context.remoteJid, `./src/grup/${list.groupCount}.jpg`, 'Babak Lanjutan');
  }
}

async function registerPlayer({
  sock,
  context,
  player,
  tournament,
  attendanceMinimum,
  deductRewardPoints = 0,
  mode = 'normal',
  dependencies,
}) {
  const { config } = dependencies;
  const statusMessage = tournamentStatusMessage(tournament);
  if (statusMessage) {
    await sendText(sock, context.remoteJid, statusMessage);
    return false;
  }

  const { ranking, previousTournamentId } = await getPreviousRanking(
    tournament.id_turnamen,
    player.id_pemain,
  );
  const pool = determineInitialPool(ranking);
  const attendance = await getAttendanceCount(player.id_pemain, tournament.id_turnamen);

  if (attendance < attendanceMinimum) {
    await sendText(
      sock,
      context.remoteJid,
      `_Presensi *${player.nama_pemain || player.nama_pengguna}* berjumlah ${attendance}, sehingga belum memenuhi syarat minimal ${attendanceMinimum} kali._`,
    );
    return false;
  }

  if (deductRewardPoints > 0) {
    const availablePoints = await getRewardPoints(
      player.id_pemain,
      config.qris.pointsUnitAmount,
    );
    if (availablePoints < deductRewardPoints) {
      await sendText(
        sock,
        context.remoteJid,
        `_Maaf, *${player.nama_pemain || player.nama_pengguna}* tidak dapat mendaftar karena reward tersedia ${availablePoints} poin, sedangkan syaratnya ${deductRewardPoints} poin._`,
      );
      return false;
    }
  }

  const insertResult = await insertData('daftar', {
    id_pemain: player.id_pemain,
    id_turnamen: tournament.id_turnamen,
    ranking_sebelum: ranking,
    pool,
    tgl_daftar: new Date(),
  });
  await sendText(sock, context.remoteJid, insertResult.message);

  if (!insertResult.success) return false;

  if (deductRewardPoints > 0) {
    const rewardReference = `${tournament.id_turnamen}${player.id_pemain}`;
    const rewardInsert = await insertData('reward', {
      id_pemain: player.id_pemain,
      ref_id: rewardReference,
      tgl_transaksi: new Date(),
      nominal: -deductRewardPoints * config.qris.pointsUnitAmount,
      kode_transaksi: 2,
      tgl_input: new Date(),
    });

    if (!rewardInsert.success) {
      dependencies.logger.warn(
        { rewardReference, playerId: player.id_pemain, tournamentId: tournament.id_turnamen },
        'Pendaftaran berhasil tetapi pengurangan reward gagal',
      );
      await sendText(
        sock,
        context.remoteJid,
        '_Pendaftaran berhasil, tetapi pencatatan pengurangan reward perlu diperiksa admin._',
      );
    }
  }

  await sendTournamentRegistrationList({
    sock,
    context,
    tournamentId: tournament.id_turnamen,
    mode,
    dependencies,
  });
  return true;
}

async function handleRegisterOther({ sock, context, command, dependencies }) {
  const [playerInput, tournamentInput] = command.parameter || [];
  if (!playerInput || !tournamentInput) {
    await sendText(
      sock,
      context.remoteJid,
      'Format belum lengkap. Contoh: *Daftarkan M. Yunus pada turnamen Kedua*.',
    );
    return true;
  }

  await setTyping(sock, context.remoteJid);
  const playerResult = await resolvePlayer(playerInput);
  const tournamentResult = await resolveTournament(tournamentInput);
  if (!playerResult.success || !tournamentResult.success) {
    await sendText(
      sock,
      context.remoteJid,
      !playerResult.success ? playerResult.message : tournamentResult.message,
    );
    return true;
  }

  await registerPlayer({
    sock,
    context,
    player: playerResult.data,
    tournament: tournamentResult.data,
    attendanceMinimum: dependencies.config.attendance.minimumAttendance,
    dependencies,
  });
  return true;
}

async function handleRegisterMe({ sock, context, command, dependencies }) {
  await setTyping(sock, context.remoteJid);
  const userResult = await getUserByContext(context);
  if (!userResult.success) {
    await sendText(sock, context.remoteJid, userResult.message || 'Pengguna belum terdaftar.');
    return true;
  }

  const user = userResult.data[0];
  const rawMode = String(command.parameter?.[0] || '').toLowerCase();
  if (!rawMode) {
    await sendText(sock, context.remoteJid, 'Alias turnamen belum dimasukkan.');
    return true;
  }

  let mode = 'normal';
  let tournamentInput = rawMode;
  let attendanceMinimum = dependencies.config.attendance.minimumAttendance;

  if (rawMode === COMMANDS.DUO_TEAM) {
    mode = COMMANDS.DUO_TEAM;
    tournamentInput = dependencies.config.tournament.duoAlias;
    attendanceMinimum = 1;
  } else if (rawMode === COMMANDS.DOUBLES) {
    mode = COMMANDS.DOUBLES;
    tournamentInput = dependencies.config.tournament.doublesAlias;
    attendanceMinimum = 0;
  }

  const tournamentResult = await resolveTournament(tournamentInput);
  if (!tournamentResult.success) {
    await sendText(sock, context.remoteJid, tournamentResult.message);
    return true;
  }

  const tournament = { ...tournamentResult.data };
  if (mode === COMMANDS.DUO_TEAM && dependencies.config.tournament.duoTournamentId) {
    tournament.id_turnamen = dependencies.config.tournament.duoTournamentId;
  }
  if (mode === COMMANDS.DOUBLES && dependencies.config.tournament.doublesTournamentId) {
    tournament.id_turnamen = dependencies.config.tournament.doublesTournamentId;
  }

  const player = {
    id_pemain: user.id_pemain,
    nama_pemain: user.nama_pengguna || user.nama_pemain || String(user.id_pemain),
  };

  if (mode === COMMANDS.DOUBLES) {
    await registerPlayer({
      sock,
      context,
      player,
      tournament,
      attendanceMinimum,
      deductRewardPoints: 0,
      mode,
      dependencies,
    });
    return true;
  }

  const attendance = await getAttendanceCount(player.id_pemain, tournament.id_turnamen);
  const { previousTournamentId } = await getPreviousRanking(
    tournament.id_turnamen,
    player.id_pemain,
  );
  const championResult = await getDataRow('*', 'peringkat', {
    id_pemain: player.id_pemain,
    id_turnamen: previousTournamentId,
  });
  const champion = championResult.success ? Number(championResult.data[0].juara || 0) : 0;

  let rewardCost = attendance >= attendanceMinimum ? 2 : Math.max(0, 5 - attendance);
  if (champion > 0) rewardCost += 1;

  await registerPlayer({
    sock,
    context,
    player,
    tournament,
    attendanceMinimum: 0,
    deductRewardPoints: rewardCost,
    mode,
    dependencies,
  });
  return true;
}

async function handleReRegistration({ sock, context, command }) {
  if (!context.isGroup) {
    await sendText(sock, context.remoteJid, 'Registrasi ulang hanya dapat dilakukan dari grup WhatsApp.');
    return true;
  }

  const playerId = command.parameter?.[0];
  if (!playerId) {
    await sendText(sock, context.remoteJid, 'ID pemain belum dimasukkan.');
    return true;
  }

  const existing = await getUserByContext(context);
  if (existing.success) {
    await sendText(
      sock,
      context.remoteJid,
      `_*${existing.data[0].nama_pengguna}* sudah melakukan registrasi ulang. Terima kasih._`,
    );
    return true;
  }

  const result = await updateData(
    'pengguna',
    { id_grup_pemain: context.senderNumber },
    { id_pemain: playerId },
  );
  await sendText(
    sock,
    context.remoteJid,
    result.success
      ? `_Registrasi ulang ID ${playerId} pada WAG berhasil._`
      : result.message,
  );
  return true;
}

module.exports = {
  handleRegisterOther,
  handleRegisterMe,
  handleReRegistration,
  registerPlayer,
  determineInitialPool,
  tournamentStatusMessage,
};
