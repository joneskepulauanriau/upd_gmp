'use strict';

const {
  insertData,
  updateData,
  deleteData,
  resetAutoincrement,
  getDataRow,
} = require('../model/gmp_service');
const { handleFile, readFileExcel } = require('../model/gmp_function');
const { sendText, setTyping } = require('../core/bot_io');
const { ADMIN_COMMANDS, APP_STATUS, COMMANDS } = require('../config/gmp_config');

const SESSION_STEPS = Object.freeze({
  ADMIN_DATA: 'ADMIN_DATA',
  IMPORT_WAIT_FILE: 'IMPORT_WAIT_FILE',
  IMPORT_CONFIRM: 'IMPORT_CONFIRM',
});

function isAdmin(context, config) {
  return Boolean(
    config.access.authorizingUser &&
      context.senderNumber === config.access.authorizingUser,
  );
}

async function getAppStatus(parameterStore, config) {
  const keywords = await parameterStore.getKeywords(config.app.parametersRecordId);
  const value = String(keywords[0] || config.app.defaultStatus).toUpperCase();
  return value === APP_STATUS.OFF ? APP_STATUS.OFF : APP_STATUS.ON;
}

async function setAppStatus(parameterStore, config, status) {
  const oldStatus = status === APP_STATUS.ON ? APP_STATUS.OFF : APP_STATUS.ON;
  await parameterStore.replaceKeyword(
    config.app.parametersRecordId,
    oldStatus,
    status,
  );
}

async function handleAdminControl({ sock, context, textLower, dependencies }) {
  const { config, parameterStore, sessions } = dependencies;
  if (!isAdmin(context, config)) return false;

  if (textLower === ADMIN_COMMANDS.APP_OFF) {
    await setAppStatus(parameterStore, config, APP_STATUS.OFF);
    await sendText(sock, context.remoteJid, 'Status Aplikasi *OFF*');
    return true;
  }

  if (textLower === ADMIN_COMMANDS.APP_ON) {
    await setAppStatus(parameterStore, config, APP_STATUS.ON);
    await sendText(sock, context.remoteJid, 'Status Aplikasi *ON*');
    return true;
  }

  if (textLower === ADMIN_COMMANDS.APP_STATUS) {
    const status = await getAppStatus(parameterStore, config);
    await sendText(sock, context.remoteJid, `Status Aplikasi *${status}*`);
    return true;
  }

  if (textLower === COMMANDS.RESET_MATCHES) {
    await setTyping(sock, context.remoteJid);
    const result = await resetAutoincrement('TRUNCATE TABLE pertandingan;');
    await sendText(sock, context.remoteJid, result?.message || 'Proses reset pertandingan selesai.');
    return true;
  }

  if (textLower === COMMANDS.ADMIN_DATA_ON) {
    sessions.set(context.sessionKey, { step: SESSION_STEPS.ADMIN_DATA });
    await sendText(
      sock,
      context.remoteJid,
      'Mode pengelolaan data aktif. Masukkan perintah tambah, perbaiki, atau hapus.',
    );
    return true;
  }

  if (textLower === COMMANDS.ADMIN_DATA_OFF) {
    sessions.delete(context.sessionKey);
    await sendText(sock, context.remoteJid, 'Mode pengelolaan data dinonaktifkan.');
    return true;
  }

  return false;
}

async function handleActiveSession({ sock, context, command, dependencies }) {
  const { sessions } = dependencies;
  const session = sessions.get(context.sessionKey);
  if (!session) return false;

  if (session.step === SESSION_STEPS.ADMIN_DATA) {
    await handleAdminDataCommand(sock, context, command);
    return true;
  }

  if (session.step === SESSION_STEPS.IMPORT_WAIT_FILE) {
    const importMessage = { ...context.raw, message: context.content };
    const result = await handleFile(sock, importMessage);
    if (!result?.success || !Array.isArray(result.data) || !result.data.length) {
      await sendText(sock, context.remoteJid, 'Proses import data tidak dapat dilanjutkan.');
      sessions.delete(context.sessionKey);
      return true;
    }

    sessions.patch(context.sessionKey, {
      step: SESSION_STEPS.IMPORT_CONFIRM,
      idTournament: result.data[0].id_turnamen,
      filename: result.filename,
    });
    await sendText(sock, context.remoteJid, 'Proses _Import Data_ (Y/T)?');
    return true;
  }

  if (session.step === SESSION_STEPS.IMPORT_CONFIRM) {
    const answer = context.text.trim().toUpperCase();
    if (!['Y', 'T'].includes(answer)) {
      await sendText(sock, context.remoteJid, 'Jawab dengan *Y* untuk lanjut atau *T* untuk batal.');
      return true;
    }

    if (answer === 'T') {
      sessions.delete(context.sessionKey);
      await sendText(sock, context.remoteJid, 'Proses import data dibatalkan.');
      return true;
    }

    await setTyping(sock, context.remoteJid);
    const rows = await readFileExcel(session.filename);
    if (!rows?.success || !Array.isArray(rows.data)) {
      sessions.delete(context.sessionKey);
      await sendText(sock, context.remoteJid, rows?.message || 'File import gagal dibaca.');
      return true;
    }

    for (const row of rows.data) {
      const where = {
        id_turnamen: row.id_turnamen,
        babak: row.babak,
        pool: row.pool,
        no_pertandingan: row.no_pertandingan,
        id_pemain: row.id_pemain,
      };
      const data = {
        id_turnamen: row.id_turnamen,
        babak: row.babak,
        pool: row.pool,
        no_pertandingan: row.no_pertandingan,
        id_pemain: row.id_pemain,
        skor_pemain: row.skor_pemain,
        id_lawan: row.id_lawan,
        skor_lawan: row.skor_lawan,
        kemenangan: row.kemenangan,
        jumlah_peserta: row.jumlah_peserta,
        poin: row.poin,
      };
      const existing = await getDataRow('*', 'pertandingan', where);
      if (existing.success) await updateData('pertandingan', data, where);
      else await insertData('pertandingan', data);
    }

    sessions.delete(context.sessionKey);
    await sendText(sock, context.remoteJid, 'Proses Import Data Selesai.');
    return true;
  }

  return false;
}

async function handleAdminDataCommand(sock, context, command) {
  const [tableRaw, ...params] = command.parameter || [];
  const table = String(tableRaw || '').toLowerCase();
  const action = String(command.perintah || '').toLowerCase();

  if (!table) {
    await sendText(sock, context.remoteJid, 'Nama tabel belum dimasukkan.');
    return;
  }

  let result;

  if (table === 'turnamen') {
    const [id, name, alias, plannedDate, realizedDate, year, rowId] = params;
    if (action === 'tambah') {
      const data = {
        id_turnamen: id,
        nama_turnamen: name,
        alias,
        tgl_turnamen: plannedDate,
        tahun: year,
        id: rowId,
      };
      if (realizedDate) data.tgl_realisasi = realizedDate;
      result = await insertData('turnamen', data);
    } else if (action === 'perbaiki') {
      result = await updateData(
        'turnamen',
        {
          nama_turnamen: name,
          alias,
          tgl_turnamen: plannedDate,
          tgl_realisasi: realizedDate,
          tahun: year,
          id: rowId,
        },
        { id_turnamen: id },
      );
    } else if (action === 'hapus') {
      result = await deleteData('turnamen', { id_turnamen: id });
    } else if (action === 'perbaiki status') {
      result = await updateData('turnamen', { status: name }, { id_turnamen: id });
    } else if (action === 'perbaiki realisasi') {
      result = await updateData(
        'turnamen',
        { tgl_realisasi: name, status: 'Buka' },
        { id_turnamen: id },
      );
    }
  } else if (table === 'daftar' && action === 'hapus') {
    result = await deleteData('daftar', {
      id_pemain: params[0],
      id_turnamen: params[1],
    });
  } else if (table === 'pengguna') {
    const [phone, name, playerId] = params;
    if (action === 'tambah') {
      result = await insertData('pengguna', {
        no_hp: phone,
        nama_pengguna: name,
        id_pemain: playerId,
      });
    } else if (action === 'perbaiki') {
      result = await updateData(
        'pengguna',
        { nama_pengguna: name, id_pemain: playerId },
        { no_hp: phone },
      );
    } else if (action === 'hapus') {
      result = await deleteData('pengguna', { no_hp: phone });
    }
  }

  await sendText(
    sock,
    context.remoteJid,
    result?.message || 'Perintah pengelolaan data tidak dikenali atau parameternya belum lengkap.',
  );
}

function startImportSession(sessions, context) {
  sessions.set(context.sessionKey, { step: SESSION_STEPS.IMPORT_WAIT_FILE });
}

module.exports = {
  SESSION_STEPS,
  isAdmin,
  getAppStatus,
  handleAdminControl,
  handleActiveSession,
  startImportSession,
};
