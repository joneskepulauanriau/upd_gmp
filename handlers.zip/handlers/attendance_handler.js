'use strict';

const fs = require('fs/promises');
const { isPointInPolygon } = require('geolib');
const { getDataRow, insertData } = require('../model/gmp_service');
const {
  DateTimeIndonesia,
  getDayNameFromDate,
} = require('../model/gmp_function');
const { sendText } = require('../core/bot_io');
const { isTimeWithinRange, formatDateSql } = require('../core/time_utils');
const { getUserByContext } = require('../services/domain_service');

let locationsCache = null;

async function loadLocations(filePath, logger) {
  if (locationsCache) return locationsCache;
  try {
    const raw = await fs.readFile(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    locationsCache = Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    logger.error({ error, filePath }, 'Gagal membaca locations.json');
    locationsCache = [];
  }
  return locationsCache;
}

function getLocationMessage(context) {
  return context.content?.locationMessage || context.content?.liveLocationMessage || null;
}

async function handleAttendanceLocation({ sock, context, dependencies }) {
  if (!context.isLocation) return false;

  const { config, logger } = dependencies;
  const userResult = await getUserByContext(context);
  if (!userResult.success) {
    await sendText(sock, context.remoteJid, 'Data pengguna tidak ditemukan. Lakukan registrasi terlebih dahulu.');
    return true;
  }

  const user = userResult.data[0];
  const locationMessage = getLocationMessage(context);
  const isForwarded = Boolean(locationMessage?.contextInfo?.isForwarded);

  if (isForwarded) {
    await sendText(
      sock,
      context.remoteJid,
      `_Presensi *${user.nama_pengguna}* tidak sah karena lokasi berasal dari pesan forward._`,
    );
    return true;
  }

  const tournamentResult = await getDataRow('*', 'turnamen', { jadwal_presensi: 1 });
  if (!tournamentResult.success) {
    await sendText(
      sock,
      context.remoteJid,
      '_Presensi tidak dapat dilakukan karena jadwal latihan tidak tersedia._',
    );
    return true;
  }

  const now = new Date();
  const dayName = getDayNameFromDate(now);
  const scheduleResult = await getDataRow('*', 'jadwal', { hari: dayName });
  if (!scheduleResult.success) {
    await sendText(sock, context.remoteJid, '_Presensi tidak dapat dilakukan karena bukan jadwal latihan._');
    return true;
  }

  const currentTime = [now.getHours(), now.getMinutes(), now.getSeconds()]
    .map((value) => String(value).padStart(2, '0'))
    .join(':');
  const schedule = scheduleResult.data[0];
  if (!isTimeWithinRange(currentTime, schedule.mulai, schedule.selesai)) {
    await sendText(sock, context.remoteJid, 'Anda melakukan presensi di luar waktu yang telah ditetapkan.');
    return true;
  }

  const point = {
    longitude: Number(locationMessage.degreesLongitude),
    latitude: Number(locationMessage.degreesLatitude),
  };
  if (!Number.isFinite(point.longitude) || !Number.isFinite(point.latitude)) {
    await sendText(sock, context.remoteJid, 'Koordinat lokasi tidak valid.');
    return true;
  }

  const locations = await loadLocations(config.paths.locations, logger);
  const matchedArea = locations.find(
    (area) => Array.isArray(area.polygon) && isPointInPolygon(point, area.polygon),
  );

  if (!matchedArea) {
    await sendText(sock, context.remoteJid, '_Lokasi presensi tidak valid. Kirim kembali lokasi dari area latihan._');
    return true;
  }

  const tournamentId = tournamentResult.data[0].id_turnamen;
  const attendanceDate = formatDateSql(now);
  const data = {
    id_pemain: user.id_pemain,
    id_turnamen: tournamentId,
    tgl_presensi: attendanceDate,
    waktu_presensi: now,
    longitude: point.longitude,
    latitude: point.latitude,
    area: matchedArea.name,
  };
  const insertResult = await insertData('presensi', data);

  if (insertResult.success) {
    await sendText(
      sock,
      context.remoteJid,
      `_*${user.nama_pengguna}* melakukan presensi di area *${matchedArea.name}* pada ${DateTimeIndonesia(now)}._`,
    );
    return true;
  }

  const existing = await getDataRow('*', 'presensi', {
    id_pemain: user.id_pemain,
    id_turnamen: tournamentId,
    tgl_presensi: attendanceDate,
  });
  const time = existing.success
    ? DateTimeIndonesia(new Date(existing.data[0].waktu_presensi))
    : 'waktu sebelumnya';
  await sendText(sock, context.remoteJid, `_Presensi sudah dilakukan pada ${time}._`);
  return true;
}

module.exports = {
  handleAttendanceLocation,
  isTimeWithinRange,
  formatDateSql,
};
