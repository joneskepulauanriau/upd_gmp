'use strict';

const { COMMANDS } = require('../config/gmp_config');
const { sendText } = require('../core/bot_io');
const {
  handleRanking,
  handleRankingInfographic,
  handleAttendanceRecap,
  handleHeadToHead,
  handleListPlayers,
  handleListTournaments,
  handleBuildPool,
  handleTournamentPlan,
  handleBestPosition,
  handleRewardList,
  handleMyReward,
  handleCheckSaldo,
  handleSaldoDetail,
} = require('./query_handlers');
const {
  handleRegisterOther,
  handleRegisterMe,
  handleReRegistration,
} = require('./registration_handlers');
const { startImportSession } = require('./admin_handler');
const { resolvePlayer } = require('../services/domain_service');

async function handlePlayerProfile({ sock, context, command }) {
  const input = command.parameter?.[0];
  if (!input) {
    await sendText(sock, context.remoteJid, 'Nama atau ID pemain belum dimasukkan.');
    return true;
  }
  const result = await resolvePlayer(input);
  if (!result.success) {
    await sendText(sock, context.remoteJid, result.message);
    return true;
  }
  const player = result.data;
  const lines = [
    '*PROFIL PEMAIN*',
    `ID Pemain: ${player.id_pemain}`,
    `Nama Pemain: ${player.nama_pemain}`,
  ];
  if (player.jenis_kelamin) lines.push(`Jenis Kelamin: ${player.jenis_kelamin}`);
  if (player.club) lines.push(`Klub: ${player.club}`);
  await sendText(sock, context.remoteJid, lines.join('\n'));
  return true;
}

function createCommandRouter(dependencies) {
  const handlers = new Map([
    [COMMANDS.RANKING, handleRanking],
    [COMMANDS.RANKING_INFOGRAPHIC, handleRankingInfographic],
    [COMMANDS.ATTENDANCE_RECAP, handleAttendanceRecap],
    [COMMANDS.HEAD_TO_HEAD, handleHeadToHead],
    [COMMANDS.HEAD_TO_HEAD_SHORT, handleHeadToHead],
    [COMMANDS.LIST_PLAYERS, handleListPlayers],
    [COMMANDS.LIST_TOURNAMENTS, handleListTournaments],
    [COMMANDS.REGISTER_PLAYER, handleRegisterOther],
    [COMMANDS.REGISTER_ME, handleRegisterMe],
    [COMMANDS.BUILD_POOL, handleBuildPool],
    [COMMANDS.TOURNAMENT_PLAN, handleTournamentPlan],
    [COMMANDS.BEST_POSITION, handleBestPosition],
    [COMMANDS.REWARD_LIST, handleRewardList],
    [COMMANDS.REWARD, handleMyReward],
    [COMMANDS.PLAYER_PROFILE, handlePlayerProfile],
    ['buat profil', handlePlayerProfile],
    [COMMANDS.RE_REGISTER, handleReRegistration],
    [COMMANDS.CHECK_SALDO, handleCheckSaldo],
    [COMMANDS.SALDO_DETAIL, handleSaldoDetail],
  ]);

  return async function route({ sock, context, command }) {
    const menu = String(command.perintah || '').toLowerCase();

    if (context.text.trim().toLowerCase() === COMMANDS.START_IMPORT) {
      startImportSession(dependencies.sessions, context);
      await sendText(sock, context.remoteJid, 'Masukkan _File Excel_ yang akan diimport:');
      return true;
    }

    const handler = handlers.get(menu);
    console.log(`Routing command: ${menu} -> ${handler ? handler.name : 'no handler found'}`);
    if (!handler) return false;
    return handler({ sock, context, command, dependencies });
  };
}

module.exports = { createCommandRouter };
