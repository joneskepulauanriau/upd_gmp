'use strict';

const path = require('path');
const {
  getDataRow,
  getDataRowQuery,
  getPeringkat,
  findHeadToHead,
  getPosisiTerbaik,
} = require('../model/gmp_service');
const {
  generateImage,
  generateImage2,
  generateImageReport,
  DateToWIB,
  DateTimeIndonesia,
} = require('../model/gmp_function');
const { sendText, sendImage, setTyping } = require('../core/bot_io');
const { getPool } = require('../core/pool');
const {
  resolvePlayer,
  resolveTournament,
  getTournamentRegistrations,
  getRewardPoints,
} = require('../services/domain_service');

function toDate(value) {
  if (value instanceof Date) return value;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatDate(value, fallback = '-') {
  const date = toDate(value);
  return date ? DateToWIB(date) : fallback;
}

function formatDateShort(value, fallback = '-') {
  const date = toDate(value);
  if (!date) return fallback;
  return [date.getDate(), date.getMonth() + 1, date.getFullYear()]
    .map((part, index) => (index < 2 ? String(part).padStart(2, '0') : String(part)))
    .join('-');
}

async function handleRanking({ sock, context, command }) {
  const input = command.parameter?.[0];
  if (!input) {
    await sendText(sock, context.remoteJid, 'ID Turnamen belum dimasukkan.');
    return true;
  }

  await setTyping(sock, context.remoteJid);
  const tournament = await resolveTournament(input);
  if (!tournament.success) {
    await sendText(sock, context.remoteJid, tournament.message);
    return true;
  }

  const ranking = await getPeringkat(tournament.data.id_turnamen);
  if (!ranking?.success || !Array.isArray(ranking.data) || !ranking.data.length) {
    await sendText(sock, context.remoteJid, ranking?.message || 'Data peringkat tidak ditemukan.');
    return true;
  }

  await generateImage(ranking, context.senderNumber);
  const filePath = `./src/images/turnamen_${tournament.data.id_turnamen}_${context.senderNumber}.png`;
  await sendImage(sock, context.remoteJid, filePath, `Peringkat ${tournament.data.nama_turnamen}`);
  return true;
}

async function handleRankingInfographic({ sock, context, command }) {
  const input = command.parameter?.[0];
  if (!input) {
    await sendText(sock, context.remoteJid, 'ID Turnamen belum dimasukkan.');
    return true;
  }

  await setTyping(sock, context.remoteJid);
  const tournament = await resolveTournament(input);
  if (!tournament.success) {
    await sendText(sock, context.remoteJid, tournament.message);
    return true;
  }

  if (String(tournament.data.status || '').toLowerCase() !== 'selesai') {
    await sendText(sock, context.remoteJid, 'Infografis tersedia setelah status turnamen selesai.');
    return true;
  }

  const ranking = await getPeringkat(tournament.data.id_turnamen);
  if (!ranking?.success || !Array.isArray(ranking.data) || !ranking.data.length) {
    await sendText(sock, context.remoteJid, 'Data peringkat tidak ditemukan.');
    return true;
  }

  await generateImage2(ranking, context.senderNumber);
  const filePath = `./src/images/infoturnamen_${tournament.data.id_turnamen}_${context.senderNumber}.png`;
  await sendImage(
    sock,
    context.remoteJid,
    filePath,
    `Informasi Grafis Peringkat ${tournament.data.nama_turnamen}`,
  );
  return true;
}

async function handleAttendanceRecap({ sock, context, command }) {
  const params = command.parameter || [];
  if (!params.length) {
    await sendText(sock, context.remoteJid, 'Alias turnamen belum dimasukkan.');
    return true;
  }

  await setTyping(sock, context.remoteJid);
  let player = null;
  let tournamentInput;
  if (params.length >= 2) {
    player = await resolvePlayer(params[0]);
    if (!player.success) {
      await sendText(sock, context.remoteJid, player.message);
      return true;
    }
    tournamentInput = params[1];
  } else {
    tournamentInput = params[0];
  }

  const tournament = await resolveTournament(tournamentInput);
  if (!tournament.success) {
    await sendText(sock, context.remoteJid, tournament.message);
    return true;
  }

  const filters = { 'presensi.id_turnamen =': tournament.data.id_turnamen };
  if (player) filters['presensi.id_pemain ='] = player.data.id_pemain;

  const result = await getDataRowQuery({
    columns: [
      'presensi.id_pemain',
      'presensi.id_turnamen',
      'pemain.nama_pemain',
      'turnamen.nama_turnamen',
      'turnamen.priode_jadwal_mulai',
      'turnamen.priode_jadwal_selesai',
      'COUNT(1) AS jumlah_hadir',
    ],
    from: 'presensi',
    joins: [
      { table: 'pemain', on: 'presensi.id_pemain = pemain.id_pemain' },
      { table: 'turnamen', on: 'presensi.id_turnamen = turnamen.id_turnamen' },
    ],
    filters,
    groupBy: 'presensi.id_pemain, presensi.id_turnamen, pemain.nama_pemain, turnamen.nama_turnamen, turnamen.priode_jadwal_mulai, turnamen.priode_jadwal_selesai',
    orderBy: 'jumlah_hadir DESC',
  });

  if (!result.success || !Array.isArray(result.data) || !result.data.length) {
    await sendText(sock, context.remoteJid, 'Data presensi tidak ditemukan.');
    return true;
  }

  const first = result.data[0];
  let text = `*REKAPITULASI PRESENSI*\n${first.nama_turnamen}\nPeriode: ${formatDate(first.priode_jadwal_mulai)} s.d. ${formatDate(first.priode_jadwal_selesai)}\n\n`;
  text += ' NO. NAMA PEMAIN          HADIR PERSYARATAN\n';
  result.data.forEach((item, index) => {
    const count = Number(item.jumlah_hadir || 0);
    const requirement = count >= 3 ? 'MS' : 'TMS';
    text += `${String(index + 1).padStart(3, ' ')} ${String(item.nama_pemain).padEnd(20, ' ')} ${count} ${requirement}\n`;
  });
  text += '\nCatatan:\n_MS = Memenuhi Syarat_\n_TMS = Tidak Memenuhi Syarat_';
  await sendText(sock, context.remoteJid, text);
  return true;
}

async function handleHeadToHead({ sock, context, command }) {
  const params = command.parameter || [];
  if (params.length !== 3) {
    await sendText(
      sock,
      context.remoteJid,
      '_Informasi belum lengkap._ Contoh:\nBuat head to head antara *M. Yunus* dengan *Utha* pada turnamen *Kedua*',
    );
    return true;
  }

  await setTyping(sock, context.remoteJid);
  const player = await resolvePlayer(params[0]);
  const opponent = await resolvePlayer(params[1]);
  const tournament = await resolveTournament(params[2]);

  for (const result of [player, opponent, tournament]) {
    if (!result.success) {
      await sendText(sock, context.remoteJid, result.message);
      return true;
    }
  }

  const h2h = await findHeadToHead(
    player.data.id_pemain,
    opponent.data.id_pemain,
    tournament.data.id_turnamen,
  );

  if (!h2h?.success || !Array.isArray(h2h.data) || !h2h.data.length) {
    await sendText(sock, context.remoteJid, 'Data head-to-head tidak ditemukan.');
    return true;
  }

  let text = `*_Head To Head_ antara ${player.data.nama_pemain} Vs ${opponent.data.nama_pemain}:*\n\n`;
  h2h.data.forEach((item) => {
    text += `Nama Turnamen : ${item.nama_turnamen}\nTanggal Turnamen : ${formatDate(item.tgl_turnamen)}\nKemenangan : ${item.jumlah_menang} - ${item.jumlah_kalah}\n\n`;
  });
  text += '*Pertandingan:*\n';
  (h2h.pertandingan || []).forEach((item) => {
    text += `Babak : _${item.keterangan_babak}_\nPool : ${item.pool}\nSkor Pertandingan : ${item.skor_pemain} / ${item.skor_lawan}\nPoin : ${Math.ceil(Number(item.poin || 0))}\n\n`;
  });
  await sendText(sock, context.remoteJid, text);
  return true;
}

async function handleListPlayers({ sock, context }) {
  await setTyping(sock, context.remoteJid);
  const result = await getDataRow('*', 'pemain');
  if (!result.success) {
    await sendText(sock, context.remoteJid, 'Data pemain tidak ditemukan.');
    return true;
  }
  let text = '*DAFTAR PEMAIN/PESERTA TURNAMEN*\n\n';
  result.data.forEach((item) => {
    if (String(item.id_pemain) !== '2023999') {
      text += `${item.id_pemain} - ${item.nama_pemain}\n`;
    }
  });
  await sendText(sock, context.remoteJid, text);
  return true;
}

async function handleListTournaments({ sock, context }) {
  await setTyping(sock, context.remoteJid);
  const result = await getDataRow('*', 'turnamen');
  if (!result.success) {
    await sendText(sock, context.remoteJid, 'Data turnamen tidak ditemukan.');
    return true;
  }
  let text = '*DAFTAR TURNAMEN*\n\n';
  result.data.forEach((item) => {
    text += `${item.id_turnamen} - ${item.nama_turnamen}\n`;
  });
  await sendText(sock, context.remoteJid, text);
  return true;
}

function buildParticipantList(registrations) {
  const groupCount = Math.ceil(registrations.length / 3);
  const mapped = registrations.map((item, index) => ({
    sequence: index + 1,
    nama_pemain: item.nama_pemain,
    ranking_sebelum: Number(item.ranking_sebelum),
    pool: getPool(groupCount, index + 1) || 'X',
  }));
  mapped.sort((a, b) => a.pool.localeCompare(b.pool) || a.ranking_sebelum - b.ranking_sebelum);

  const first = registrations[0];
  let text = `DAFTAR PESERTA TURNAMEN\n${first.nama_turnamen}\nTanggal : ${formatDateShort(first.tgl_realisasi)}\n\n*No. Nama Peserta  #B/L  Pool*\n`;
  mapped.forEach((item, index) => {
    const previous = item.ranking_sebelum === 99 ? 0 : item.ranking_sebelum;
    text += `${String(index + 1).padStart(3, ' ')}. ${item.nama_pemain} #${item.sequence}/${previous} *${item.pool}*\n`;
  });
  return { text, groupCount };
}

async function handleBuildPool({ sock, context, command }) {
  const input = command.parameter?.[0];
  if (!input) {
    await sendText(sock, context.remoteJid, 'Alias turnamen belum dimasukkan.');
    return true;
  }

  await setTyping(sock, context.remoteJid);
  const tournament = await resolveTournament(input);
  if (!tournament.success) {
    await sendText(sock, context.remoteJid, tournament.message);
    return true;
  }

  const status = String(tournament.data.status || '').toLowerCase();
  if (status === 'tutup') {
    await sendText(
      sock,
      context.remoteJid,
      `Status turnamen *TUTUP* dan akan dibuka tanggal *${formatDate(tournament.data.tgl_turnamen)}*.`,
    );
    return true;
  }
  if (status === 'selesai') {
    await sendText(
      sock,
      context.remoteJid,
      `Status turnamen *SELESAI* pada tanggal *${formatDate(tournament.data.tgl_realisasi)}*.`,
    );
    return true;
  }

  const result = await getTournamentRegistrations(tournament.data.id_turnamen);
  if (!result.success || !result.data.length) {
    await sendText(sock, context.remoteJid, '_Data tidak tersedia._');
    return true;
  }

  const list = buildParticipantList(result.data);
  await sendText(sock, context.remoteJid, list.text);
  if (list.groupCount !== 2) {
    await sendImage(sock, context.remoteJid, `./src/grup/${list.groupCount}.jpg`, 'Babak Lanjutan');
  }
  return true;
}

async function handleTournamentPlan({ sock, context, command }) {
  await setTyping(sock, context.remoteJid);
  const result = await getDataRow('*', 'turnamen');
  if (!result.success) {
    await sendText(sock, context.remoteJid, 'Data rencana turnamen tidak ditemukan.');
    return true;
  }

  const year = command.parameter?.[0] ? String(command.parameter[0]) : '';
  const data = year
    ? result.data.filter((item) => String(item.tahun) === year)
    : result.data;
  if (!data.length) {
    await sendText(sock, context.remoteJid, `Data turnamen tahun ${year} tidak ditemukan.`);
    return true;
  }

  const output = `./src/images/laporan_turnamen_${context.senderNumber}.png`;
  const columns = year
    ? [
        { key: 'id', label: 'ID', x: 50 },
        { key: 'nama_turnamen', label: 'NAMA TURNAMEN', x: 90 },
        { key: 'tgl_turnamen', label: 'RENCANA', x: 450, format: (value) => formatDateShort(value) },
        { key: 'tgl_realisasi', label: 'REALISASI', x: 550, format: (value) => formatDateShort(value) },
        { key: 'status', label: 'STATUS', x: 650 },
      ]
    : [
        { key: 'id', label: 'ID', x: 50 },
        { key: 'nama_turnamen', label: 'NAMA TURNAMEN', x: 90 },
        { key: 'tgl_turnamen', label: 'RENCANA', x: 450, format: (value) => formatDateShort(value) },
        { key: 'tgl_realisasi', label: 'REALISASI', x: 550, format: (value) => formatDateShort(value) },
        { key: 'tahun', label: 'TAHUN', x: 650 },
      ];

  await generateImageReport({
    title: 'JADWAL RENCANA TURNAMEN INTERNAL',
    subtitle: 'PTM GEDUNG MERAH PUTIH',
    periode: year,
    output,
    columns,
    data,
  });
  await sendImage(sock, context.remoteJid, output, 'Jadwal Rencana Turnamen');
  return true;
}

async function handleBestPosition({ sock, context, command }) {
  const params = command.parameter || [];
  if (params.length !== 2) {
    await sendText(
      sock,
      context.remoteJid,
      '_Informasi tidak lengkap._\n\nContoh:\nBuat posisi terbaik untuk *M. Yunus* pada turnamen *Pertama*',
    );
    return true;
  }

  await setTyping(sock, context.remoteJid);
  const player = await resolvePlayer(params[0]);
  const tournament = await resolveTournament(params[1]);
  if (!player.success || !tournament.success) {
    await sendText(sock, context.remoteJid, !player.success ? player.message : tournament.message);
    return true;
  }

  const result = await getPosisiTerbaik(tournament.data.id_turnamen, player.data.id_pemain);
  if (!result?.success || !Array.isArray(result.data) || !result.data.length) {
    await sendText(sock, context.remoteJid, 'Data tidak ditemukan.');
    return true;
  }

  let text = `*Posisi Terbaik ${player.data.nama_pemain} Pada Turnamen ${tournament.data.nama_turnamen}:*\n\n`;
  result.data.forEach((item) => {
    text += `Nama Lawan : ${item.nama_lawan}\nBabak : ${item.keterangan_babak}\nPool : ${item.pool}\nSkor : ${item.skor_pemain} / ${item.skor_lawan}\nPoin : ${item.poin}\n\n`;
  });
  await sendText(sock, context.remoteJid, text);
  return true;
}

async function handleRewardList({ sock, context, dependencies }) {
  await setTyping(sock, context.remoteJid);
  const result = await getDataRowQuery({
    columns: ['pemain.nama_pemain', 'SUM(reward.nominal) AS total_reward', 'reward.id_pemain'],
    from: 'reward',
    joins: [{ table: 'pemain', on: 'reward.id_pemain = pemain.id_pemain' }],
    filters: {},
    groupBy: 'reward.id_pemain, pemain.nama_pemain',
  });
  if (!result.success || !result.data.length) {
    await sendText(sock, context.remoteJid, 'Data reward tidak ditemukan.');
    return true;
  }

  const unit = dependencies.config.qris.pointsUnitAmount;
  let text = '*DAFTAR REWARD*\n\n';
  result.data.forEach((item) => {
    text += `${item.nama_pemain} ${(Number(item.total_reward || 0) / unit).toLocaleString('id-ID')} poin\n`;
  });
  await sendText(sock, context.remoteJid, text);
  return true;
}

async function handleMyReward({ sock, context, dependencies }) {
  const userResult = await dependencies.getUserByContext(context);
  if (!userResult.success) {
    await sendText(sock, context.remoteJid, 'Pengguna belum terdaftar.');
    return true;
  }
  const player = userResult.data[0];
  const points = await getRewardPoints(player.id_pemain, dependencies.config.qris.pointsUnitAmount);
  await sendText(
    sock,
    context.remoteJid,
    `Total reward *${player.nama_pengguna || player.id_pemain}*: *${points.toLocaleString('id-ID')} poin*.`,
  );
  return true;
}

async function handleCheckSaldo({ sock, context}) {
    await setTyping(sock, context.remoteJid);
    const result = await getDataRowQuery({
    columns: [
    `saldo.tgl_transaksi AS tgl_transaksi`,
    `saldo.uraian AS uraian`,
    `sum(saldo.jumlah) AS jumlah`,
    `saldo.kode_transaksi AS kode_transaksi`,
    ],
    from: 'saldo',
    joins: [],
    filters: {},
    groupBy: `saldo.kode_transaksi`,
    orderBy: `saldo.kode_transaksi`,
  });

  if (!result.success) {
    await sendText(sock, context.remoteJid, 'Data saldo tidak ditemukan.');
    return false;
  }

  let totalDonasi = 0;
  let jumlah=0;
  let text = '*SALDO PTM GMP*\n\n';
  result.data.forEach((item) => {
    if(item.kode_transaksi==='D'){
      totalDonasi += Number(item.jumlah || 0);
    } else {
      totalDonasi -= Number(item.jumlah || 0);
    }
    jumlah += Number(item.jumlah || 0);
    text += `${item.kode_transaksi=='D'?String('Total Donasi').padEnd(20,' '):String('Total Pengeluaran').padEnd(20,' ')} ${jumlah.toLocaleString('id-ID')} \n`;
  });
  text += `\n*Total Saldo Donasi*: *${totalDonasi.toLocaleString('id-ID')}*\n`;
  await sendText(sock, context.remoteJid, text);
  return true;
}

async function handleSaldoDetail({ sock, context}) {
  try {
    await setTyping(sock, context.remoteJid);
    const result = await getDataRowQuery({
      columns: [
      `saldo.tgl_transaksi AS tgl_transaksi`,
      `saldo.uraian AS uraian`,
      `saldo.jumlah AS jumlah`,
      `saldo.kode_transaksi AS kode_transaksi`,
      ],
      from: 'saldo',
      joins: [],
      filters: {},
      orderBy: `saldo.kode_transaksi ASC, saldo.tgl_transaksi ASC`,
    });
  
    if (!result.success || result.data.length === 0) {
        await sendText(sock, context.remoteJid,'Data saldo tidak ditemukan.');
        return false;
    }
  
    let totalDonasi = 0;
    let jumlahdonasi=0;
    let jumlahkeluar =0;
    let pindah=false;
    let text = '*SALDO PTM GMP (DETAIL)*\n\n*DONASI:*\nTGL TRANSAKSI URAIAN               JUMLAH\n';
    result.data.forEach((item) => {
      const kodeTransaksi = String(item.kode_transaksi || '').toUpperCase();
      const jumlah = Number(item.jumlah) || 0;
      const tanggal = formatDateShort(item.tgl_transaksi);
      const uraian = String(item.uraian || '-');
      const jumlahFormat = jumlah.toLocaleString('id-ID');
  
      if(kodeTransaksi==='D'){
        totalDonasi += Number(item.jumlah || 0);
        jumlahdonasi += Number(item.jumlah || 0);
      } else {
        totalDonasi -= Number(item.jumlah || 0);
        jumlahkeluar += Number(item.jumlah || 0);
      }
      if (!pindah && kodeTransaksi==='K'){
        text += `*Jumlah Donasi: ${jumlahdonasi.toLocaleString('id-ID')}*\n\n*PENGELUARAN:*\nTGL TRANSAKSI URAIAN               JUMLAH\n`;
        pindah=true;
      }
      text += `${String(tanggal).padEnd(13,' ')} ${String(uraian).padEnd(30,' ')} ${String(jumlahFormat).padStart(15,' ')}\n`;
    });
    text += `*Jumlah Pengeluaran: ${jumlahkeluar.toLocaleString('id-ID')}*\n\n*Total Saldo Donasi*: *${totalDonasi.toLocaleString('id-ID')}*\n`;
    await sendText(sock, context.remoteJid, text);
    return true;
    } catch (error) {
      await sendText(sock, context.remoteJid,'Terjadi kesalahan saat memeriksa saldo:', error);
      return false;
    }
}

module.exports = {
  handleRanking,
  handleRankingInfographic,
  handleAttendanceRecap,
  handleHeadToHead,
  handleListPlayers,
  handleListTournaments,
  handleBuildPool,
  handleTournamentPlan,
  handleBestPosition,
  handleRewardList,
  handleMyReward,
  handleCheckSaldo,
  handleSaldoDetail,
  buildParticipantList,
  formatDate,
  formatDateShort,
};
