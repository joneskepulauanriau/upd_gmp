'use strict';

const MASTER_POOL = Object.freeze([
  {},
  { A: [1, 2, 3] },
  { A: [1, 3, 5], B: [2, 4, 6] },
  { A: [1, 4, 7], B: [3, 6, 9], C: [2, 5, 8] },
  { A: [1, 5, 9], B: [4, 8, 12], C: [3, 7, 11], D: [2, 6, 10] },
  { A: [1, 6, 11], B: [4, 9, 14], C: [5, 10, 15], D: [3, 8, 13], E: [2, 7, 12] },
  { A: [1, 7, 13], B: [5, 11, 17], C: [4, 10, 16], D: [3, 9, 15], E: [6, 12, 18], F: [2, 8, 14] },
  { A: [1, 8, 15], B: [5, 12, 19], C: [6, 13, 20], D: [4, 11, 18], E: [3, 10, 17], F: [7, 14, 21], G: [2, 9, 16] },
  { A: [1, 9, 17], B: [5, 13, 21], C: [6, 14, 22], D: [4, 12, 20], E: [3, 11, 19], F: [7, 15, 23], G: [8, 16, 24], H: [2, 10, 18] },
]);

function getPool(groupCount, position) {
  const groups = MASTER_POOL[Number(groupCount)];
  if (!groups || !Number.isInteger(Number(position))) return null;

  for (const [pool, positions] of Object.entries(groups)) {
    if (positions.includes(Number(position))) return pool;
  }
  return null;
}

function pairDuo(players = []) {
  const sorted = [...players].sort(
    (a, b) => Number(a.ranking_sebelum) - Number(b.ranking_sebelum),
  );
  const result = [];
  let left = 0;
  let right = sorted.length - 1;

  while (left < right) {
    result.push({
      nama_pasangan: `${sorted[left].nama_pemain} (${sorted[left].ranking_sebelum})/${sorted[right].nama_pemain} (${sorted[right].ranking_sebelum})`,
      ranking_sekarang: result.length + 1,
    });
    left += 1;
    right -= 1;
  }

  if (left === right) {
    result.push({
      nama_pasangan: `${sorted[left].nama_pemain} (${sorted[left].ranking_sebelum}) _tanpa pasangan_`,
      ranking_sekarang: result.length + 1,
    });
  }

  return result;
}

module.exports = { MASTER_POOL, getPool, pairDuo };
