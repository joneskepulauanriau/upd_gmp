'use strict';

function normalizeCommandText(text = '') {
  return String(text)
    .replace(/\s+/g, ' ')
    .replace(/[;,\.]/g, ' ')
    .replace(/h2h|pertemuan langsung/gi, 'head to head')
    .replace(/\btampilkan\b/gi, 'buat')
    .replace(/\bberegu duo\b/gi, 'bereguduo')
    .replace(/\bcek poin reward\b|\bcek poin\b|\bcek reward\b/gi, 'reward')
    .replace(/\bcek saldo donasi\b/gi, 'cek saldo gmp')
    .replace(/\bcek saldo detail\b/gi, 'cek saldo detil')
    .replace(/\bdaftar poin reward\b|\bdaftar poin\b|\bdaftar reward\b/gi, 'listreward')
    .replace(/\brangking\b|\bperingkat\b/gi, 'ranking')
    .replace(/\btahap\b|\bperiode\b|\bpriode\b|\bperbaikan peringkat\b/gi, '')
    .replace(/\butnuk\b|\buntk\b|\bntuk\b|\btuk\b|\butk\b/gi, 'untuk')
    .replace(/\b(?:ke[-\s]?1|ke[-\s]?satu|kesatu|satu|pertama)\b/gi, 'pertama')
    .replace(/\b(?:ke[-\s]?2|ke[-\s]?dua|kedua|dua)\b/gi, 'kedua')
    .replace(/\b(?:ke[-\s]?3|ke[-\s]?tiga|ketiga|tiga)\b/gi, 'ketiga')
    .replace(/\b(?:ke[-\s]?4|ke[-\s]?empat|keempat|empat)\b/gi, 'keempat')
    .replace(/\b(?:ke[-\s]?5|ke[-\s]?lima|kelima|lima)\b/gi, 'kelima')
    .replace(/\b(?:ke[-\s]?6|ke[-\s]?enam|keenam|enam)\b/gi, 'keenam')
    .replace(/\b(?:ke[-\s]?7|ke[-\s]?tujuh|ketujuh|tujuh)\b/gi, 'ketujuh')
    .replace(/\b(?:ke[-\s]?8|ke[-\s]?delapan|kedelapan|delapan)\b/gi, 'kedelapan')
    .replace(/\b(?:ke[-\s]?9|ke[-\s]?sembilan|kesembilan|sembilan)\b/gi, 'kesembilan')
    .replace(/\b(?:ke[-\s]?10|ke[-\s]?sepuluh|kesepuluh|sepuluh)\b/gi, 'kesepuluh')
    .replace(/\b(?:ke[-\s]?11|ke[-\s]?sebelas|kesebelas|ke sebelas|sebelas)\b/gi, 'kesebelas')
    .replace(/\b(?:ke[-\s]?12|ke[-\s]?dua belas|ke dua belas|kedua belas|dua belas)\b/gi, 'keduabelas')
    .replace(/\b(?:ke[-\s]?13|ke[-\s]?tiga belas|ke tiga belas|ketiga belas|tiga belas)\b/gi, 'ketigabelas')
    .replace(/\b(?:ke[-\s]?14|ke[-\s]?empat belas|ke empat belas|keempat belas|empat belas)\b/gi, 'keempatbelas')
    .replace(/\b(?:ke[-\s]?15|ke[-\s]?lima belas|ke lima belas|kelima belas|lima belas)\b/gi, 'kelimbelas')
    .replace(/\b(?:ke[-\s]?16|ke[-\s]?enam belas|ke enam belas|keenam belas|enam belas)\b/gi, 'keenambelas')
    .replace(/\b(?:ke[-\s]?17|ke[-\s]?tujuh belas|ke tujuh belas|ketujuh belas|tujuh belas)\b/gi, 'ketujuhbelas')
    .replace(/\b(ke[-\s]?18|ke18|ke[-\s]?delapan belas|ke delapan belas|kedelapan belas|delapan belas)\b/gi, 'kedelapanbelas')
    .replace(/\b(ke[-\s]?19|ke19|ke[-\s]?sembilan belas|ke sembilan belas|kesembilan belas|sembilan belas)\b/gi, 'kesembilanbelas')
    .replace(/\b(ke[-\s]?20|ke20|ke[-\s]?dua puluh|ke dua puluh|kedua puluh|kedua puluh)\b/gi, 'keduapuluh')
    .replace(/\b(ke[-\s]?21|ke21|ke[-\s]?dua puluh satu|ke dua puluh satu|kedua puluh satu|dua puluh satu)\b/gi, 'keduapuluhsatu')
    .replace(/\b(ke[-\s]?22|ke22|ke[-\s]?dua puluh dua|ke dua puluh dua|kedua puluh dua|dua puluh dua)\b/gi, 'keduapuluhdua')
    .replace(/\b(ke[-\s]?23|ke23|ke[-\s]?dua puluh tiga|ke dua puluh tiga|kedua puluh tiga|dua puluh tiga)\b/gi, 'keduapuluhtiga')
   .replace(/\s+/g, ' ')
    .trim();
}

function parseCommand(text = '') {
  const raw = String(text).trim();
  if (!raw) return { perintah: '', parameter: [] };

  const registration = raw.match(/^registrasi\s+ulang(?:\s+id\s+pemain)?\s+(\d{6,})/i);
  if (registration) return { perintah: 'registrasi ulang', parameter: [registration[1]] };

  const adminData = raw.match(
    /^(tambah|hapus|perbaiki(?:\s+status|\s+realisasi)?)\s+(\w+)\s*\{([^}]*)\}$/i,
  );
  if (adminData) {
    return {
      perintah: adminData[1].toLowerCase(),
      parameter: [adminData[2].toLowerCase(), ...adminData[3].split(',').map((v) => v.trim())],
    };
  }

  const plan = raw.match(/tampilkan\s+rencana\s+turnamen\s+tahun\s+(\d{4})/i);
  if (plan) return { perintah: 'buat rencana turnamen', parameter: [plan[1]] };

  let normalized = normalizeCommandText(raw);

  const profile = normalized.match(/^buat profil(?: pemain)?\s+(.+)$/i);
  if (profile) return { perintah: 'buat profil pemain', parameter: [profile[1].trim()] };

  const pool = normalized.match(/^buat pool .*turnamen\s+(.+)$/i);
  if (pool) return { perintah: 'buat pool', parameter: [pool[1].trim()] };

  const registerMe = normalized.match(/^daftarkan saya(?: .*turnamen)?\s+(.+)$/i);
  if (registerMe) return { perintah: 'daftarkan saya', parameter: [registerMe[1].trim()] };

  const registerOther = normalized.match(/^daftarkan\s+(.+?)\s+(?:pada\s+)?turnamen\s+(.+)$/i);
  if (registerOther) {
    return {
      perintah: 'daftarkan',
      parameter: [registerOther[1].trim(), registerOther[2].trim()],
    };
  }

  const separators = ['antara', 'dengan', 'untuk', 'pada', 'turnamen', 'dan'];
  let firstSeparatorIndex = -1;
  for (const word of separators) {
    const index = normalized.toLowerCase().indexOf(` ${word} `);
    if (index !== -1 && (firstSeparatorIndex === -1 || index < firstSeparatorIndex)) {
      firstSeparatorIndex = index;
    }
  }

  const perintah = firstSeparatorIndex !== -1
    ? normalized.substring(0, firstSeparatorIndex).trim()
    : normalized.trim();
  const paramText = firstSeparatorIndex !== -1
    ? normalized.substring(firstSeparatorIndex).trim()
    : '';
  const numbers = paramText.match(/\d{6,}/g) || [];
  const phrases = paramText
    .replace(/\b(antara|dengan|untuk|pada|turnamen|dan)\b/gi, '|')
    .split('|')
    .map((value) => value.trim())
    .filter((value) => value && !/^\d{6,}$/.test(value));

  return { perintah: perintah.toLowerCase(), parameter: [...numbers, ...phrases] };
}

module.exports = { parseCommand, normalizeCommandText };
