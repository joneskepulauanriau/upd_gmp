'use strict';

function normalizeText(text = '') {
  return String(text)
    .replace(/\r/g, '\n')
    .replace(/[|]/g, 'I')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeDigits(text = '') {
  return String(text).replace(/[^\d]/g, '');
}

function splitLines(text = '') {
  return String(text)
    .split(/\r?\n/)
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean);
}

function findValueByLabel(text = '', labelRegex) {
  const lines = splitLines(text);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    labelRegex.lastIndex = 0;
    if (!labelRegex.test(line)) continue;

    const parts = line.split(/[:：]/);
    if (parts.length > 1) {
      const value = parts.slice(1).join(':').trim();
      if (value) return value;
    }

    labelRegex.lastIndex = 0;
    const afterLabel = line
      .replace(labelRegex, '')
      .replace(/^[:：\-\s]+/, '')
      .trim();
    if (afterLabel) return afterLabel;
    if (lines[index + 1]) return lines[index + 1].trim();
  }
  return '';
}

function getRefId(text = '') {
  const raw = normalizeText(text);
  const label = /(?:ref(?:erence)?\s*id|ref\.?\s*id|no\.?\s*ref(?:erensi)?|nomor\s*referensi|id\s*transaksi|nomor\s*transaksi|transaction\s*id|\bref\b|\bstan\b)/i;
  const value = findValueByLabel(text, label);

  if (value) {
    const match = value.match(/[A-Z0-9][A-Z0-9\-/.]{4,}/i);
    if (match) return match[0];
  }

  const patterns = [
    /\b(?:REF|TRX|FT|QRIS|INV)[A-Z0-9\-/.]{6,}\b/i,
    /\b\d{10,30}\b/,
  ];
  for (const pattern of patterns) {
    const match = raw.match(pattern);
    if (match) return match[0];
  }
  return '-';
}

function normalizeOcrLines(text = '') {
  return String(text)
    .replace(/\r/g, '\n')
    .replace(/[：]/g, ':')
    .replace(/[|]/g, 'I')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .split('\n')
    .map((line) => line.replace(/\s+/g, ' ').replace(/\s+:/g, ':').trim())
    .filter(Boolean);
}

function cleanNominalToInteger(value = '') {
  let nominal = String(value).replace(/\s/g, '').replace(/,00$/i, '');
  nominal = nominal.replace(/[^\d]/g, '');
  const result = Number(nominal);
  return Number.isSafeInteger(result) ? result : 0;
}

function extractNominalFromText(text = '') {
  const patterns = [
    /(?:rp|idr)\s*([0-9][0-9.,]*)/i,
    /(?:nominal|total|jumlah|amount|nilai\s*transaksi|jumlah\s*pembayaran)\s*[:\-]?\s*([0-9][0-9.,]*)/i,
  ];
  for (const pattern of patterns) {
    const match = String(text).match(pattern);
    if (match) return cleanNominalToInteger(match[1]);
  }
  return 0;
}

function getNominal(text = '') {
  if (typeof text !== 'string' || !text.trim()) return 0;
  const lines = normalizeOcrLines(text);
  const labelRegex = /(?:nominal|total|jumlah|amount|nilai\s*transaksi|jumlah\s*pembayaran)/i;

  for (const line of lines) {
    if (!labelRegex.test(line)) continue;
    const amount = extractNominalFromText(line);
    if (amount > 0) return amount;
  }
  for (const line of lines) {
    const amount = extractNominalFromText(line);
    if (amount > 0) return amount;
  }
  return extractNominalFromText(lines.join(' '));
}

function validateQrisText(text, terminalId) {
  const normalized = normalizeText(text).toLowerCase();
  const digits = normalizeDigits(text);
  const normalizedTerminal = String(terminalId || '');
  const terminalFound =
    normalized.includes(normalizedTerminal.toLowerCase()) ||
    digits.includes(normalizeDigits(normalizedTerminal));
  return terminalFound && /berhasil|successful|success/i.test(normalized);
}

module.exports = {
  normalizeText,
  normalizeDigits,
  getRefId,
  getNominal,
  cleanNominalToInteger,
  validateQrisText,
};
