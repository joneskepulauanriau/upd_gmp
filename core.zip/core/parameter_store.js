'use strict';

const fs = require('fs/promises');
const path = require('path');

class ParameterStore {
  constructor(filePath) {
    this.filePath = filePath;
  }

  async ensureFile() {
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });
    try {
      await fs.access(this.filePath);
    } catch {
      await fs.writeFile(this.filePath, '[]\n', 'utf8');
    }
  }

  async readAll() {
    await this.ensureFile();
    const raw = await fs.readFile(this.filePath, 'utf8');
    if (!raw.trim()) return [];

    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      throw new Error(`Format JSON parameter tidak valid: ${error.message}`);
    }
  }

  async writeAll(data) {
    const tempPath = `${this.filePath}.tmp`;
    await fs.writeFile(tempPath, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
    await fs.rename(tempPath, this.filePath);
  }

  async getKeywords(id) {
    const data = await this.readAll();
    const item = data.find((row) => String(row.id) === String(id));
    return Array.isArray(item?.keywords) ? item.keywords : [];
  }

  async replaceKeyword(id, oldKeyword, newKeyword) {
    const data = await this.readAll();
    const index = data.findIndex((row) => String(row.id) === String(id));

    if (index === -1) {
      data.push({ id: String(id), keywords: [newKeyword] });
      await this.writeAll(data);
      return true;
    }

    if (!Array.isArray(data[index].keywords)) data[index].keywords = [];
    const keywordIndex = data[index].keywords.findIndex(
      (item) => String(item).toUpperCase() === String(oldKeyword).toUpperCase(),
    );

    if (keywordIndex === -1) {
      if (!data[index].keywords.includes(newKeyword)) data[index].keywords.unshift(newKeyword);
    } else {
      data[index].keywords[keywordIndex] = newKeyword;
    }

    await this.writeAll(data);
    return true;
  }
}

module.exports = { ParameterStore };
