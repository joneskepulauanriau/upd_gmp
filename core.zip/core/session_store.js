'use strict';

class SessionStore {
  constructor({ ttlMs = 30 * 60 * 1000 } = {}) {
    this.ttlMs = ttlMs;
    this.sessions = new Map();
  }

  set(key, value) {
    this.sessions.set(key, {
      ...value,
      updatedAt: Date.now(),
    });
    return this.get(key);
  }

  get(key) {
    const session = this.sessions.get(key);
    if (!session) return null;

    if (Date.now() - session.updatedAt > this.ttlMs) {
      this.sessions.delete(key);
      return null;
    }

    session.updatedAt = Date.now();
    return session;
  }

  patch(key, changes) {
    const current = this.get(key) || {};
    return this.set(key, { ...current, ...changes });
  }

  delete(key) {
    return this.sessions.delete(key);
  }

  clear() {
    this.sessions.clear();
  }
}

module.exports = { SessionStore };
