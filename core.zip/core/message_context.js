'use strict';

function unwrapMessage(message) {
  let content = message?.message || null;
  if (!content) return null;

  const wrappers = [
    'ephemeralMessage',
    'viewOnceMessage',
    'viewOnceMessageV2',
    'viewOnceMessageV2Extension',
    'documentWithCaptionMessage',
  ];

  let changed = true;
  while (changed && content) {
    changed = false;
    for (const wrapper of wrappers) {
      if (content[wrapper]?.message) {
        content = content[wrapper].message;
        changed = true;
        break;
      }
    }
  }

  return content;
}

function getText(content) {
  if (!content) return '';
  return String(
    content.conversation ||
      content.extendedTextMessage?.text ||
      content.imageMessage?.caption ||
      content.documentMessage?.caption ||
      content.videoMessage?.caption ||
      '',
  ).trim();
}

function getMessageType(content) {
  return content ? Object.keys(content)[0] || '' : '';
}

function isImageContent(content) {
  if (!content) return false;
  if (content.imageMessage) return true;
  return Boolean(content.documentMessage?.mimetype?.startsWith('image/'));
}

function isLocationContent(content) {
  return Boolean(content?.locationMessage || content?.liveLocationMessage);
}

function normalizeUserNumber(jid = '') {
  return String(jid).split('@')[0].replace(/\D/g, '');
}

function createMessageContext(msg) {
  const content = unwrapMessage(msg);
  const remoteJid = String(msg?.key?.remoteJid || '');
  const participantJid = String(msg?.key?.participant || '');
  const isGroup = remoteJid.endsWith('@g.us');
  const senderJid = isGroup ? participantJid : remoteJid;
  const senderNumber = normalizeUserNumber(senderJid || remoteJid);

  return {
    raw: msg,
    content,
    remoteJid,
    participantJid,
    senderJid,
    senderNumber,
    senderName: msg?.pushName || 'Tanpa Nama',
    isGroup,
    isFromMe: Boolean(msg?.key?.fromMe),
    text: getText(content),
    messageType: getMessageType(content),
    sessionKey: `${remoteJid}:${senderNumber}`,
    isImage: isImageContent(content),
    isLocation: isLocationContent(content),
  };
}

module.exports = {
  unwrapMessage,
  getText,
  getMessageType,
  isImageContent,
  isLocationContent,
  normalizeUserNumber,
  createMessageContext,
};
