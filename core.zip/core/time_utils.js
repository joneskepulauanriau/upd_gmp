'use strict';

function isTimeWithinRange(current, start, end) {
  const validTime = /^\d{2}:\d{2}:\d{2}$/;
  if (!validTime.test(current) || !validTime.test(start) || !validTime.test(end)) return false;
  return current >= start && current <= end;
}

function formatDateSql(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

module.exports = { isTimeWithinRange, formatDateSql };
