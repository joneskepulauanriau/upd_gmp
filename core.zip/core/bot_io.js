'use strict';

async function sendText(sock, jid, text) {
  return sock.sendMessage(jid, { text: String(text) });
}

async function sendImage(sock, jid, imagePath, caption = '') {
  return sock.sendMessage(jid, {
    image: { url: imagePath },
    caption,
  });
}

async function setTyping(sock, jid) {
  try {
    await sock.sendPresenceUpdate('composing', jid);
  } catch {
    // Presence failure must not stop command processing.
  }
}

module.exports = { sendText, sendImage, setTyping };
